package exam2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Exam2 {

	public static void main(String[] args) {
		List<StudentVO> list = new ArrayList<StudentVO>();
		try {
			FileReader fr = new FileReader("file/data.txt");
			BufferedReader br = new BufferedReader(fr);
			
			StudentVO stu = null;
			String str = "";
			while (true) {
				str = br.readLine();
				if (str == null) break;
				String[] strArr = str.split(",");
				stu = new StudentVO();
				stu.setId(Integer.parseInt(strArr[0]));
				stu.setName(strArr[1]);
				stu.setKor(Integer.parseInt(strArr[2]));
				stu.setEng(Integer.parseInt(strArr[3]));
				stu.setMath(Integer.parseInt(strArr[4]));
				list.add(stu);
			}
			br.close();
			
			FileWriter fw = new FileWriter("file/result.txt");
			for (StudentVO student : list) {
				fw.write(student.getId() + ",");
				fw.write(student.getName() + ",");
				fw.write(student.getKor() + ",");
				fw.write(student.getEng() + ",");
				fw.write(student.getMath() + ",");
				fw.write(student.getTot() + ",");
				fw.write(student.getAvg() + "\n");
				fw.flush();
			}
			fw.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
